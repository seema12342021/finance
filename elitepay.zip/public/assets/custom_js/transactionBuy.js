$(document).ready(function(){
	transactionBuy();
});
  

function transactionBuy(){
	var table = $('#transactionBuy_datatable').DataTable({
        processing: true,
        serverSide: true,
        ajax: siteUrl+"show_transactionBuy",
        columns: [ 
            {data: 'DT_RowIndex'},
            {data: 'user'},
            {data: 'total_crypto'},
            {data: 'total_inr_price'},
            {data: "status"},
            {data: 'action', orderable: false, searchable: false},
        ]
    });
}

